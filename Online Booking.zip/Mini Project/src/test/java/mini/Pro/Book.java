package mini.Pro;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import java.time.Duration;
import java.util.List;

public class Book {

    public static void main(String[] args) throws InterruptedException {

        ChromeDriver driver = new ChromeDriver();
        driver.get("https://www.bookswagon.com/");
        driver.manage().window().maximize();
        
        WebElement searchBox = driver.findElement(By.id("inputbar"));
        Thread.sleep(4000);
        searchBox.sendKeys("Selenium Webdriver");
        Thread.sleep(4000);
        
        driver.findElement(By.xpath("/html/body/form/header/div[1]/div/div[2]/div/span/input")).click();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
        
        WebElement sortDropdown = driver.findElement(By.xpath("/html/body/form/div[10]/div[1]/div[2]/div[1]/div[2]/div/div[3]/select"));
        sortDropdown.click();
        
        Select c = new Select(sortDropdown);
        c.selectByVisibleText("Price - Low to High");
        Thread.sleep(4000);
        
        WebElement element = driver.findElement(By.xpath("//*[@id=\"site-wrapper\"]/div[1]/div[2]/div[1]/div[1]/div/b"));
        Thread.sleep(3000);
        System.out.println("Total number of results: " + element.getText());
        
        List<WebElement> names = driver.findElements(By.xpath("//div[@class='title']/a"));
        if (names.size() > 10) {
            System.out.println("More than 10 results found.");
        } else {
            System.out.println("Less than 10 results found.");
        }
        
        List<WebElement> prices = driver.findElements(By.xpath("//div[@class='sell']"));
        for (int i = 0; i < Math.min(names.size(), 5); i++) {
            System.out.println("Product: " + names.get(i).getText() + " " + prices.get(i).getText());
        }
        
        driver.quit();
    }
}










	
	
	
	
	
	
	
	
	
