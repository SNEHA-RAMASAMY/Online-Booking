package mini.Pro.tests;

import mini.Pro.pages.BookswagonPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

public class BookTest {

    WebDriver driver;
    BookswagonPage page;

    @BeforeClass
    public void setUp() {
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().window().maximize();
        driver.get("https://www.bookswagon.com/");
        page = new BookswagonPage(driver);
    }

    @Test
    public void open() throws InterruptedException {
        page.searchBook("Selenium Webdriver");
        page.sortByPriceLowToHigh();
        Thread.sleep(3000);

        System.out.println("Total number of results: " + page.getTotalResultsText());

        List<WebElement> titleElements = page.getBookTitles();
        List<WebElement> priceElements = page.getBookPrices();

        List<String> titles = new ArrayList<>();
        for (WebElement e : titleElements) {
            titles.add(e.getText());
        }

        List<String> prices = new ArrayList<>();
        for (WebElement e : priceElements) {
            prices.add(e.getText());
        }

        System.out.println("Number of results: " + titles.size());

        if (titles.size() > 10) {
            System.out.println("More than 10 results found.");
        } else {
            System.out.println("Less than 10 results found.");
        }

        for (int i = 0; i < Math.min(titles.size(), 5); i++) {
            System.out.println("Product: " + titles.get(i) + " - " + prices.get(i));
        }
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}
