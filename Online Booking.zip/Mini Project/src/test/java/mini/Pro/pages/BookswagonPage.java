package mini.Pro.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

public class BookswagonPage {

    WebDriver driver;

    public BookswagonPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(id = "inputbar")
    WebElement searchBox;

    @FindBy(xpath = "/html/body/form/header/div[1]/div/div[2]/div/span/input")
    WebElement searchButton;

    @FindBy(xpath = "/html/body/form/div[10]/div[1]/div[2]/div[1]/div[2]/div/div[3]/select")
    WebElement sortDropdown;

    @FindBy(xpath = "//*[@id=\"site-wrapper\"]/div[1]/div[2]/div[1]/div[1]/div/b")
    WebElement totalResults;

    @FindBy(xpath = "//div[@class='title']/a")
    List<WebElement> bookTitles;

    @FindBy(xpath = "//div[@class='sell']")
    List<WebElement> bookPrices;

    public void searchBook(String bookName) throws InterruptedException {
        searchBox.sendKeys(bookName);
        searchButton.click();
        Thread.sleep(3000);
    }

    public void sortByPriceLowToHigh() {
        Select select = new Select(sortDropdown);
        select.selectByVisibleText("Price - Low to High");
    }

    public String getTotalResultsText() {
        return totalResults.getText();
    }

    public List<WebElement> getBookTitles() {
        return bookTitles;
    }

    public List<WebElement> getBookPrices() {
        return bookPrices;
    }
}
